export default function PreviewModul({ formData }) {
  return (
    <div style={{ background: "#fff", padding: 24 }}>
      <h2>{formData.judul}</h2>
      <p><b>Mata Pelajaran:</b> {formData.mataPelajaran}</p>
      <p><b>Kelas:</b> {formData.kelas}</p>
      <h3>Kompetensi Awal</h3>
      <p>{formData.kompetensiAwal}</p>
      <h3>Profil Pelajar Pancasila</h3>
      <p>{formData.profilPelajar}</p>
      <h3>Sarana dan Prasarana</h3>
      <p>{formData.sarana}</p>
      <h3>Target Peserta Didik</h3>
      <p>{formData.target}</p>
      <h3>Model Pembelajaran</h3>
      <p>{formData.model}</p>
      <h3>Langkah Pembelajaran</h3>
      <b>Pendahuluan:</b> <p>{formData.langkahPendahuluan}</p>
      <b>Inti:</b> <p>{formData.langkahInti}</p>
      <b>Penutup:</b> <p>{formData.langkahPenutup}</p>
      <h3>Penilaian</h3>
      <p>{formData.penilaian}</p>
      <h3>Lampiran</h3>
      <p>{formData.lampiran}</p>
    </div>
  );
}