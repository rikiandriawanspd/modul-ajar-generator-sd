import { useRouter } from "next/router";

export default function ModulForm({ formData, setFormData }) {
  const router = useRouter();
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    localStorage.setItem("modul", JSON.stringify(formData));
    router.push("/preview");
  };
  return (
    <form onSubmit={handleSubmit}>
      <label>Judul Modul: <input name="judul" value={formData.judul} onChange={handleChange} /></label><br/>
      <label>Mata Pelajaran: <input name="mataPelajaran" value={formData.mataPelajaran} onChange={handleChange} /></label><br/>
      <label>Kelas: <input name="kelas" value={formData.kelas} onChange={handleChange} /></label><br/>
      <label>Kompetensi Awal: <textarea name="kompetensiAwal" value={formData.kompetensiAwal} onChange={handleChange} /></label><br/>
      <label>Profil Pelajar Pancasila: <textarea name="profilPelajar" value={formData.profilPelajar} onChange={handleChange} /></label><br/>
      <label>Sarana dan Prasarana: <textarea name="sarana" value={formData.sarana} onChange={handleChange} /></label><br/>
      <label>Target Peserta Didik: <textarea name="target" value={formData.target} onChange={handleChange} /></label><br/>
      <label>Model Pembelajaran: <textarea name="model" value={formData.model} onChange={handleChange} /></label><br/>
      <label>Langkah Pembelajaran - Pendahuluan: <textarea name="langkahPendahuluan" value={formData.langkahPendahuluan} onChange={handleChange} /></label><br/>
      <label>Langkah Pembelajaran - Inti: <textarea name="langkahInti" value={formData.langkahInti} onChange={handleChange} /></label><br/>
      <label>Langkah Pembelajaran - Penutup: <textarea name="langkahPenutup" value={formData.langkahPenutup} onChange={handleChange} /></label><br/>
      <label>Penilaian: <textarea name="penilaian" value={formData.penilaian} onChange={handleChange} /></label><br/>
      <label>Lampiran: <textarea name="lampiran" value={formData.lampiran} onChange={handleChange} /></label><br/>
      <button type="submit">Preview & Export</button>
    </form>
  );
}