import { Box, FormControl, FormLabel, Textarea, Input } from "@chakra-ui/react";
import { ChangeEvent } from "react";

type Field = { label: string; name: string; type?: "text" | "textarea"; required?: boolean };
type Props = {
  schema: Field[];
  values: Record<string, string>;
  onChange: (name: string, value: string) => void;
};

export default function DynamicForm({ schema, values, onChange }: Props) {
  return (
    <Box as="form" p={4}>
      {schema.map((field) => (
        <FormControl key={field.name} isRequired={field.required} mb={3}>
          <FormLabel>{field.label}</FormLabel>
          {field.type === "textarea" ? (
            <Textarea
              value={values[field.name] || ""}
              onChange={(e: ChangeEvent<HTMLTextAreaElement>) => onChange(field.name, e.target.value)}
              rows={4}
            />
          ) : (
            <Input
              value={values[field.name] || ""}
              onChange={(e: ChangeEvent<HTMLInputElement>) => onChange(field.name, e.target.value)}
            />
          )}
        </FormControl>
      ))}
    </Box>
  );
}