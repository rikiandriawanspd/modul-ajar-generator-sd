type Field = { label: string; name: string };
export default function PreviewModul({ schema, values }: { schema: Field[]; values: Record<string, string> }) {
  return (
    <div style={{ background: "#fff", padding: 24, borderRadius: 8 }}>
      {schema.map(field => (
        <div key={field.name} style={{ marginBottom: 12 }}>
          <strong>{field.label}</strong>
          <div>{values[field.name] || <em><small>(belum diisi)</small></em>}</div>
        </div>
      ))}
    </div>
  );
}