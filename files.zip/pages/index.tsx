import { useState } from "react";
import { signIn, useSession } from "next-auth/react";
import DynamicForm from "../components/DynamicForm";
import PreviewModul from "../components/PreviewModul";
import { generateModulPDF } from "../utils/pdfGenerator";
import kerangkaTemplate from "../lib/kerangkaTemplate";

export default function Home() {
  const { data: session } = useSession();
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [downloading, setDownloading] = useState(false);

  const handleChange = (name: string, value: string) => setFormData(f => ({ ...f, [name]: value }));

  async function handleDownload() {
    setDownloading(true);
    const pdfBytes = await generateModulPDF(formData);
    const blob = new Blob([pdfBytes], { type: "application/pdf" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "modul-ajar.pdf";
    link.click();
    setDownloading(false);
  }

  return (
    <div style={{ display: "flex", gap: 32 }}>
      <div style={{ flex: 1 }}>
        {!session ? (
          <button onClick={() => signIn("google")}>Login untuk Simpan Modul</button>
        ) : null}
        <DynamicForm
          schema={kerangkaTemplate}
          values={formData}
          onChange={handleChange}
        />
        <button disabled={downloading} onClick={handleDownload}>
          {downloading ? "Membuat PDF..." : "Download PDF"}
        </button>
      </div>
      <div style={{ flex: 1 }}>
        <PreviewModul schema={kerangkaTemplate} values={formData} />
      </div>
    </div>
  );
}