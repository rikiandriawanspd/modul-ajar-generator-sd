import { useEffect, useState } from "react";
import { generatePDF } from "../utils/pdf";
import PreviewModul from "../components/PreviewModul";

export default function PreviewPage() {
  const [formData, setFormData] = useState(null);

  useEffect(() => {
    setFormData(JSON.parse(localStorage.getItem("modul")));
  }, []);

  if (!formData) return <div>Loading...</div>;

  return (
    <div>
      <PreviewModul formData={formData} />
      <button onClick={() => generatePDF(formData)}>Download PDF</button>
    </div>
  );
}