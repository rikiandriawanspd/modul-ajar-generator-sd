import { getSession, signOut } from "next-auth/react";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import ModulCard from "../../components/ModulCard";

export default function Dashboard() {
  const [moduls, setModuls] = useState([]);
  const router = useRouter();
  useEffect(() => {
    // fetch user modul from API
    fetch("/api/modul").then(res => res.json()).then(setModuls);
  }, []);
  return (
    <div>
      <h1>Modul Saya</h1>
      <button onClick={() => router.push("/")}>Buat Modul Baru</button>
      <button onClick={() => signOut()}>Logout</button>
      <div>
        {moduls.map(modul => <ModulCard key={modul._id} modul={modul} />)}
      </div>
    </div>
  );
}