import { useState } from "react";
import ModulForm from "../components/ModulForm";

export default function Home() {
  const [formData, setFormData] = useState({
    judul: "",
    mataPelajaran: "",
    kelas: "",
    kompetensiAwal: "",
    profilPelajar: "",
    sarana: "",
    target: "",
    model: "",
    langkahPendahuluan: "",
    langkahInti: "",
    langkahPenutup: "",
    penilaian: "",
    lampiran: "",
  });

  return (
    <div>
      <h1>Generator Modul Ajar</h1>
      <ModulForm formData={formData} setFormData={setFormData} />
    </div>
  );
}