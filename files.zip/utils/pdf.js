import jsPDF from "jspdf";

export function generatePDF(formData) {
  const doc = new jsPDF();
  doc.setFontSize(16);
  doc.text(formData.judul, 10, 10);
  doc.setFontSize(12);
  doc.text(`Mata Pelajaran: ${formData.mataPelajaran}`, 10, 20);
  doc.text(`Kelas: ${formData.kelas}`, 10, 30);

  let y = 40;
  doc.text("Kompetensi Awal:", 10, y); y += 10;
  doc.text(formData.kompetensiAwal, 10, y); y += 20;
  doc.text("Profil Pelajar Pancasila:", 10, y); y += 10;
  doc.text(formData.profilPelajar, 10, y); y += 20;
  doc.text("Sarana dan Prasarana:", 10, y); y += 10;
  doc.text(formData.sarana, 10, y); y += 20;
  doc.text("Target Peserta Didik:", 10, y); y += 10;
  doc.text(formData.target, 10, y); y += 20;
  doc.text("Model Pembelajaran:", 10, y); y += 10;
  doc.text(formData.model, 10, y); y += 20;
  doc.text("Langkah Pembelajaran:", 10, y); y += 10;
  doc.text(`Pendahuluan: ${formData.langkahPendahuluan}`, 10, y); y += 10;
  doc.text(`Inti: ${formData.langkahInti}`, 10, y); y += 10;
  doc.text(`Penutup: ${formData.langkahPenutup}`, 10, y); y += 20;
  doc.text("Penilaian:", 10, y); y += 10;
  doc.text(formData.penilaian, 10, y); y += 20;
  doc.text("Lampiran:", 10, y); y += 10;
  doc.text(formData.lampiran, 10, y);

  doc.save("modul-ajar.pdf");
}