import { PDFDocument, StandardFonts, rgb } from "pdf-lib";

export async function generateModulPDF(formData: Record<string, string>, templateName = "Modul Ajar") {
  const pdfDoc = await PDFDocument.create();
  const page = pdfDoc.addPage([595, 842]);
  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);

  let y = 800;
  page.drawText(templateName, { x: 50, y, size: 20, font, color: rgb(0, 0, 0.7) });
  y -= 30;
  for (const [header, content] of Object.entries(formData)) {
    page.drawText(header, { x: 50, y, size: 14, font, color: rgb(0, 0.1, 0.6) });
    y -= 20;
    page.drawText(content || "-", { x: 60, y, size: 11, font, color: rgb(0.1, 0.1, 0.1) });
    y -= 40;
    if (y < 80) {
      y = 800;
      pdfDoc.addPage([595, 842]);
    }
  }
  const pdfBytes = await pdfDoc.save();
  return pdfBytes;
}